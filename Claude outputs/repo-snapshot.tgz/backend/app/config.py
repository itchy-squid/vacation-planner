from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Runtime configuration, sourced from environment variables (or a local
    .env file — see .env.example at the repo root). In Azure, these are set
    as Container App environment variables / secrets (see infra/)."""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    environment: str = "development"

    # postgresql+psycopg://user:pass@host:5432/dbname for local dev (matches
    # docker-compose.yml). In production this has no password in the URL at
    # all — see use_azure_ad_auth below — and needs sslmode=require; e.g.
    # postgresql+psycopg://app-backend@pg-vacplanner-prod.postgres.database.azure.com:5432/vacation_planner?sslmode=require
    database_url: str = "postgresql+psycopg://planner:planner@localhost:5432/vacation_planner"

    # When true, the password half of every new database connection is
    # replaced with a freshly fetched Microsoft Entra ID access token (see
    # app/db.py install_azure_ad_token_provider) instead of whatever's in
    # database_url — the "any auth to the database should use managed
    # identities" requirement. Set via the Container App's environment in
    # production (see infra/modules/container-app-backend.bicep); left
    # false for local dev against the docker-compose Postgres, which still
    # uses a plain password.
    use_azure_ad_auth: bool = False

    # The Container App's user-assigned managed identity client ID (see
    # infra/modules/managed-identity.bicep), so DefaultAzureCredential picks
    # that identity specifically rather than guessing among several. Left
    # unset for a developer running against Azure with their own `az login`
    # session (DefaultAzureCredential falls back to the Azure CLI credential).
    azure_client_id: str | None = None

    # Azure Container Apps / App Service built-in auth ("Easy Auth") forwards
    # signed-in Entra ID users via X-MS-CLIENT-PRINCIPAL* headers — see
    # app/auth.py. Locally, with no Easy Auth in front of you, requests are
    # attributed to this fake user instead of being rejected.
    dev_user_email: str = "mei@example.com"

    # Blob storage a chosen pin photo gets mirrored into (see
    # app/photo_storage.py) — the account's blob endpoint, e.g.
    # https://vacationplannerdevpinphotos.blob.core.windows.net (see
    # infra/modules/storage-account.bicep's blobEndpoint output). Left
    # unset for local dev, which has no storage account: photo_storage's
    # functions all no-op in that case, so pins just keep the hotlinked
    # photo they already had (see photo_storage.py's module docstring).
    azure_storage_account_url: str | None = None
    azure_storage_container: str = "pin-photos"

    # The SPA's origin, e.g. https://vacations.dev.amandasanti.com. Any
    # non-API GET that reaches this backend is redirected there (see
    # app/routers/spa_redirect.py) -- chiefly Easy Auth's
    # /.auth/login/done page, whose "Return to website" button links to
    # this API host's "/". Set from the first corsOrigins entry in
    # infra/modules/container-app-backend.bicep. Unset locally, where the
    # Vite dev server serves the SPA and those paths just 404.
    frontend_url: str | None = None

    @property
    def is_development(self) -> bool:
        return self.environment.lower() in {"development", "dev", "local"}


@lru_cache
def get_settings() -> Settings:
    return Settings()
